package com.parallel.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.parallel.spring.beans.Account;
import com.parallel.spring.beans.Transaction;
import com.parallel.spring.exceptions.AccountMismatchException;
import com.parallel.spring.exceptions.AccountNotFound;
import com.parallel.spring.exceptions.InvalidAmountException;
import com.parallel.spring.service.BankService;

@RestController
public class BankController {
	@Autowired
	private BankService bankService;

	@PostMapping("/create")
	public List<Account> addAccount(@RequestBody Account account) {
		return bankService.createAcccount(account);
	}

	@GetMapping("/accounts")
	public List<Account> getAllAccounts() {
		return bankService.getAllAccounts();
	}

	@GetMapping("/accounts/deposit")
	public List<Account> deposit(@RequestParam int accno, @RequestParam double amount)
			throws InvalidAmountException, AccountNotFound {

		return bankService.deposit(accno, amount);
	}

	@GetMapping("/accounts/withdraw")
	public List<Account> withdraw(@RequestParam int accno, @RequestParam double amount)
			throws InvalidAmountException, AccountNotFound {

		return bankService.withdraw(accno, amount);
	}

	@GetMapping("/accounts/transfer")
	public List<Account> fundsTransfer(@RequestParam int accno1, @RequestParam int accno2, @RequestParam double amount)
			throws AccountMismatchException, InvalidAmountException, AccountNotFound {

		return bankService.fundsTransfer(accno1, accno2, amount);
	}

	@GetMapping("/transactions")
	public List<Transaction> getAllTransactions() {
		return bankService.getAllTransactions();

	}

	@GetMapping("/balance")
	public double getBalance(@RequestParam int accno) throws AccountNotFound {
		return bankService.getInitialBalance(accno);
	}

	@GetMapping("/get")
	public List<Transaction> getTransactionByAccno(@RequestParam int accno) {
		return bankService.getTransactionByAccno(accno);

	}

}
